#  Robot Raconteur(R) - A communication library for robotics and automation systems
#  Copyright (C) 2014 John Wason <wason@wasontech.com>
#                     Wason Technology, LLC
#
#  This program is released under the terms of the Robot Raconteur(R)
#  license.  Full text can be found at  http://robotraconteur.com/license2 .
#  Attribute to this library as "Robot Raconteur(R)" in documentation or
#  packaging.  This software is royalty free for commercial use under
#  the conditions of the license.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

import RobotRaconteurPython
import threading
import string


class RobotRaconteurException(Exception):
    def __init__(self,errorcode,errorname,errormessage):
        self.errorcode=errorcode
        self.errorname=errorname
        self.message=errormessage
    def __str__(self):
        return self.errorname + " " + self.message

class ConnectionException(RobotRaconteurException):
    def __init__(self,message):
        super(ConnectionException,self).__init__(RobotRaconteurPython.MessageErrorType_ConnectionError,
            'RobotRaconteur.ConnectionError',message)

class ProtocolException(RobotRaconteurException):
    def __init__(self,message):
        super(ProtocolException,self).__init__(RobotRaconteurPython.MessageErrorType_ProtocolError,
            'RobotRaconteur.ProtocolError',message)

class ServiceNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(ServiceNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_ServiceNotFound,
            'RobotRaconteur.ServiceNotFound',message)

class ObjectNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(ObjectNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_ObjectNotFound,
            'RobotRaconteur.ObjectNotFound',message)

class InvalidEndpointException(RobotRaconteurException):
    def __init__(self,message):
        super(InvalidEndpointException,self).__init__(RobotRaconteurPython.MessageErrorType_InvalidEndpoint,
            'RobotRaconteur.InvalidEndpoint',message)

class EndpointCommunicationFatalException(RobotRaconteurException):
    def __init__(self,message):
        super(EndpointCommunicationFatalException,self).__init__(RobotRaconteurPython.MessageErrorType_EndpointCommunicationFatalError,
            'RobotRaconteur.EndpointCommunicationFatalError',message)

class NodeNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(NodeNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_NodeNotFound,
            'RobotRaconteur.NodeNotFound',message)

class ServiceException(RobotRaconteurException):
    def __init__(self,message):
        super(ServiceException,self).__init__(RobotRaconteurPython.MessageErrorType_ServiceError,
            'RobotRaconteur.ServiceError',message)

class MemberNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(MemberNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_MemberNotFound,
            'RobotRaconteur.MemberNotFound',message)

class MemberFormatMismatchException(RobotRaconteurException):
    def __init__(self,message):
        super(MemberFormatMismatchException,self).__init__(RobotRaconteurPython.MessageErrorType_MemberFormatMismatch,
            'RobotRaconteur.MemberFormatMismatch',message)

class DataTypeMismatchException(RobotRaconteurException):
    def __init__(self,message):
        super(DataTypeMismatchException,self).__init__(RobotRaconteurPython.MessageErrorType_DataTypeMismatch,
            'RobotRaconteur.DataTypeMismatch',message)

class DataTypeException(RobotRaconteurException):
    def __init__(self,message):
        super(DataTypeException,self).__init__(RobotRaconteurPython.MessageErrorType_DataTypeError,
            'RobotRaconteur.DataTypeError',message)

class DataSerializationException(RobotRaconteurException):
    def __init__(self,message):
        super(DataSerializationException,self).__init__(RobotRaconteurPython.MessageErrorType_DataSerializationError,
            'RobotRaconteur.DataSerializationError',message)

class MessageEntryNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(MessageEntryNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_MessageEntryNotFound,
            'RobotRaconteur.MessageEntryNotFound',message)

class MessageElementNotFoundException(RobotRaconteurException):
    def __init__(self,message):
        super(MessageElementNotFoundException,self).__init__(RobotRaconteurPython.MessageErrorType_MessageElementNotFound,
            'RobotRaconteur.MessageElementNotFound',message)

class UnknownException(RobotRaconteurException):
    def __init__(self,name,message):
        super(UnknownException,self).__init__(RobotRaconteurPython.MessageErrorType_UnknownError,
            name,message)

class RobotRaconteurRemoteException(RobotRaconteurException):
    def __init__(self,error,message):
        super(RobotRaconteurRemoteException,self).__init__(RobotRaconteurPython.MessageErrorType_RemoteError,
            error,message)

class TransactionTimeoutException(RobotRaconteurException):
    def __init__(self,message):
        super(TransactionTimeoutException,self).__init__(RobotRaconteurPython.MessageErrorType_TransactionTimeout,
            'RobotRaconteur.TransactionTimeout',message)

class AuthenticationException(RobotRaconteurException):
    def __init__(self,message):
        super(AuthenticationException,self).__init__(RobotRaconteurPython.MessageErrorType_AuthenticationError,
            'RobotRaconteur.AuthenticationError',message)

class ObjectLockedException(RobotRaconteurException):
    def __init__(self,message):
        super(ObjectLockedException,self).__init__(RobotRaconteurPython.MessageErrorType_ObjectLockedError,
            'RobotRaconteur.ObjectLockedError',message)

class RobotRaconteurExceptionUtil:

    @staticmethod
    def ExceptionToErrorCode(exception, entry):
        if (type(exception) is RobotRaconteurException):
            return exception.errorcode, exception.errorname, exception.message
        else:
            return RobotRaconteurPython.MessageErrorType_RemoteError, type(exception).__name__, exception.message

    @staticmethod
    def ErrorCodeToException(code,name,errstr):

        if (code==RobotRaconteurPython.MessageErrorType_ConnectionError):
            return ConnectionException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_ProtocolError):
            return ProtocolException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_ServiceNotFound):
            return ServiceNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_ObjectNotFound):
            return ObjectNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_InvalidEndpoint):
            return InvalidEndpointException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_EndpointCommunicationFatalError):
            return EndpointCommunicationFatalException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_NodeNotFound):
            return NodeNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_ServiceError):
            return ServiceException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_MemberNotFound):
            return MemberNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_MemberFormatMismatch):
            return MemberFormatMismatchException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_DataTypeMismatch):
            return DataTypeMismatchException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_DataTypeError):
            return DataTypeException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_DataSerializationError):
            return DataSerializationException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_MessageEntryNotFound):
            return MessageEntryNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_MessageElementNotFound):
            return MessageElementNotFoundException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_UnknownError):
            return UnknownException(name,errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_RemoteError):
            e= GetExceptionType(name)
            return e(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_TransactionTimeout):
            return TransactionTimeoutException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_AuthenticationError):
            return AuthenticationException(errstr)
        elif (code==RobotRaconteurPython.MessageErrorType_ObjectLockedError):
            return ObjectLockedException(errstr)
        else:
            return RobotRaconteurException(code,name,errstr)

_generated_exceptions=dict()
_generated_exceptions_lock=threading.Lock()

def GetExceptionType(exception_name):
    if (not (isinstance(exception_name,str) or isinstance(exception_name,unicode))):
        return Exception
    ex1=exception_name.replace('.','__')
    ex2=''.join([x for x in ex1 if x in (string.letters + string.digits + "_")])
    with _generated_exceptions_lock:
        if (exception_name in _generated_exceptions):
            return _generated_exceptions[exception_name]
        else:
            execstr="""class """ + ex2 + """(RobotRaconteurRemoteException):
    def __init__(self,message):
        super(self.__class__,self).__init__(\"""" + exception_name + """\",message)
newexp= """ + ex2
            exec(execstr)
            _generated_exceptions[exception_name]=newexp
            return newexp